<?php

/**
 * Main WooCommerce Class.
 *
 * @class WooCommerce
 *
 * @property \WC_Payment_Gateways $payment_gateways
 * @property \WC_Checkout         $checkout
 */
final class WooCommerce {}
